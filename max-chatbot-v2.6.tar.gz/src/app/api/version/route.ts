// GET /api/version — lightweight endpoint, no auth required
// Returns just the version number — for monitoring/health checks

import { NextResponse } from 'next/server'

export const runtime = 'nodejs'

export async function GET() {
  return NextResponse.json({ version: '2.6' })
}
