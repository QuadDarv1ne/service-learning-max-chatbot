// POST /api/auth/login
// Body: { password: string }
// Rate limited: max 5 attempts per 15 minutes per IP

import { NextResponse } from 'next/server'
import { verifyPassword, createSession } from '@/lib/auth'
import { logAdmin, getClientIpAsync } from '@/lib/admin-log'

export const runtime = 'nodejs'

// Simple in-memory rate limiter — resets on server restart
const attempts = new Map<string, { count: number; firstAt: number }>()
const MAX_ATTEMPTS = 5
const WINDOW_MS = 15 * 60 * 1000 // 15 minutes

export async function POST(req: Request) {
  // Rate limiting check
  const ip = await getClientIpAsync() || 'unknown'
  const ipKey = ip.slice(0, 16) // use hash if available, otherwise 'unknown'
  const now = Date.now()
  const record = attempts.get(ipKey)

  if (record) {
    // Reset if window expired
    if (now - record.firstAt > WINDOW_MS) {
      attempts.delete(ipKey)
    } else if (record.count >= MAX_ATTEMPTS) {
      const remaining = Math.ceil((WINDOW_MS - (now - record.firstAt)) / 60000)
      await logAdmin({
        action: 'login_failed',
        ok: false,
        error: 'rate_limited',
        detail: `IP ${ipKey} заблокирован на ${remaining} мин`,
      })
      return NextResponse.json(
        { error: 'too_many_attempts', detail: `Слишком много попыток. Повторите через ${remaining} мин.` },
        { status: 429 },
      )
    }
  }

  let body: { password?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'invalid_json' }, { status: 400 })
  }

  const password = body.password ?? ''
  if (!password) {
    // Record failed attempt
    const rec = attempts.get(ipKey) || { count: 0, firstAt: now }
    rec.count++
    attempts.set(ipKey, rec)

    await logAdmin({
      action: 'login_failed',
      ok: false,
      error: 'no_password_provided',
    })
    return NextResponse.json({ error: 'password_required' }, { status: 400 })
  }

  if (!verifyPassword(password)) {
    // Record failed attempt
    const rec = attempts.get(ipKey) || { count: 0, firstAt: now }
    rec.count++
    attempts.set(ipKey, rec)

    const remaining = MAX_ATTEMPTS - rec.count
    await logAdmin({
      action: 'login_failed',
      ok: false,
      error: 'invalid_credentials',
      detail: remaining > 0 ? `Осталось попыток: ${remaining}` : 'IP заблокирован',
    })

    if (remaining <= 0) {
      return NextResponse.json(
        { error: 'too_many_attempts', detail: 'Слишком много попыток. Повторите через 15 мин.' },
        { status: 429 },
      )
    }

    return NextResponse.json(
      { error: 'invalid_credentials', detail: `Неверный пароль. Осталось попыток: ${remaining}` },
      { status: 401 },
    )
  }

  // Success — clear rate limit for this IP
  attempts.delete(ipKey)

  await createSession()
  await logAdmin({
    action: 'login',
    detail: 'Успешный вход в админ-панель',
  })
  return NextResponse.json({ ok: true })
}
