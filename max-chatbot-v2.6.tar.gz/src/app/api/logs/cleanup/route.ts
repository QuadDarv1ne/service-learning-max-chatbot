// POST /api/logs/cleanup?days=90 — delete old logs
// GET /api/logs/cleanup?days=90 — dry run: preview what would be deleted

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isAuthenticated } from '@/lib/auth'
import { logAdmin } from '@/lib/admin-log'

export const runtime = 'nodejs'

export async function GET(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const days = parseInt(searchParams.get('days') || '90', 10)
  const cutoff = new Date()
  cutoff.setDate(cutoff.getDate() - days)

  const adminCutoff = new Date()
  adminCutoff.setDate(adminCutoff.getDate() - 180)

  const [logsToDelete, adminToDelete] = await Promise.all([
    db.messageLog.count({ where: { createdAt: { lt: cutoff } } }),
    db.adminActionLog.count({ where: { createdAt: { lt: adminCutoff } } }),
  ])

  return NextResponse.json({
    dryRun: true,
    days,
    cutoff: cutoff.toISOString(),
    logsToDelete,
    adminActionsToDelete: adminToDelete,
  })
}

export async function POST(req: Request) {
  if (!(await isAuthenticated())) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const days = parseInt(searchParams.get('days') || '90', 10)
  const cutoff = new Date()
  cutoff.setDate(cutoff.getDate() - days)

  try {
    // Count before delete
    const countBefore = await db.messageLog.count({
      where: { createdAt: { lt: cutoff } },
    })

    // Delete old logs
    const result = await db.messageLog.deleteMany({
      where: { createdAt: { lt: cutoff } },
    })

    // Also clean up old admin actions (keep 180 days)
    const adminCutoff = new Date()
    adminCutoff.setDate(adminCutoff.getDate() - 180)
    const adminResult = await db.adminActionLog.deleteMany({
      where: { createdAt: { lt: adminCutoff } },
    })

    await logAdmin({
      action: 'logs_cleanup',
      detail: `Удалено ${result.count} логов старше ${days} дней и ${adminResult.count} audit записей старше 180 дней`,
    })

    return NextResponse.json({
      ok: true,
      deletedLogs: result.count,
      deletedAdminActions: adminResult.count,
      cutoff: cutoff.toISOString(),
    })
  } catch (e) {
    return NextResponse.json(
      { error: 'cleanup_failed', detail: e instanceof Error ? e.message : String(e) },
      { status: 500 },
    )
  }
}
