import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Home } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="max-w-md w-full space-y-6 text-center">
        <div className="space-y-2">
          <h1 className="text-6xl font-bold text-muted-foreground/30">404</h1>
          <h2 className="text-xl font-semibold">Страница не найдена</h2>
          <p className="text-sm text-muted-foreground">
            Запрашиваемая страница не существует или была перемещена.
          </p>
        </div>
        <Link href="/">
          <Button variant="default" className="flex items-center gap-2 mx-auto">
            <Home className="h-4 w-4" />
            На главную
          </Button>
        </Link>
      </div>
    </div>
  )
}
