'use client'

import { useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { AlertTriangle } from 'lucide-react'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error('App error:', error)
  }, [error])

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="max-w-md w-full space-y-6 text-center">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-2xl bg-red-100 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl font-bold">Что-то пошло не так</h1>
          <p className="text-sm text-muted-foreground">
            Произошла ошибка при загрузке страницы. Попробуйте обновить или вернуться позже.
          </p>
          {error?.message && (
            <p className="text-xs text-muted-foreground font-mono bg-muted p-2 rounded-md mt-2">
              {error.message}
            </p>
          )}
        </div>
        <div className="flex gap-2 justify-center">
          <Button onClick={reset} variant="default">
            Попробовать снова
          </Button>
          <Button onClick={() => window.location.href = '/'} variant="outline">
            На главную
          </Button>
        </div>
      </div>
    </div>
  )
}
