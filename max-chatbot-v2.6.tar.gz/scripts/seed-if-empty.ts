// Seed database ONLY if it's empty — safe to run on every startup
// Uses the shared PrismaClient instance from src/lib/db.ts

import { db } from '../src/lib/db'
import { seedDatabase } from './seed'

async function main() {
  const existingCategories = await db.category.count()
  if (existingCategories > 0) {
    console.log(`✅ Database already has ${existingCategories} categories — skipping seed.`)
    return
  }

  console.log('🌱 Database is empty — running initial seed...')
  await seedDatabase(db)

  const totalCats = await db.category.count()
  const totalItems = await db.faqItem.count()
  const totalCmds = await db.botCommand.count()
  console.log(`\n✅ Seed complete: ${totalCats} categories, ${totalItems} FAQ items, ${totalCmds} commands`)
}

main()
  .catch((e) => {
    console.error('Seed-if-empty failed:', e)
    // Don't exit with error code — let the app start anyway
  })
  .finally(async () => {
    await db.$disconnect()
  })
